#version 330

#define MH_VERSION 5
#define MH_OFFSET 67
#define XP_HIDE true
#define XP_OFFSET vec3(-10600.0, -10600.0, -10600.0)
#define XP_COLOR vec3(0.501, 1.0, 0.125)
#define XP_COLOR_SHADOW vec3(0.0, 0.0, 0.0)

#moj_import <minecraft:globals.glsl>

// Function to convert a vertical ascent into a ID.
float get_id(float offset) {
    if (offset <= 0.0)
    return 0.0;
    return trunc(offset / 1000.0);
}

bool is_at(int offset, int pos) { return offset == pos || offset == pos + 8; }
bool is_at(int offset, int pos0, int pos1) { return is_at(offset, pos0) || is_at(offset, pos1); }
bool is_at(int offset, int pos0, int pos1, int pos2, int pos3) { return is_at(offset, pos0, pos1) || is_at(offset, pos2, pos3); }
bool within(vec3 a, vec3 b, float threshold) { return abs(length(a - b)) < threshold; }

void applyCustomHud() {
    vec3 pos = Position;
    vec2 guiSize = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    int guiScale = int(round(guiSize.x / (1 / ScreenSize.x)));

    float id = get_id((round(MH_OFFSET - pos.y)) * -1);

    // Detect if GUI text.
    if (id > 99 && Color.a != 0.0) {
        float yOffset = 0.0;
        float xOffset = 0.0;
        float layer = 0.0;
        vec2 scale = vec2(1, 1);
        bool outlined = false;

        if (id >= 100.0 && id <= 131.0) {
            switch (int(id)) {
                case 100:
                    xOffset = int(guiSize.x * (-50.0/100))+23;
                    yOffset = int(guiSize.y * (50.0/100))-13;
                    layer = 0.9998;
                    break;
                case 101:
                    xOffset = int(guiSize.x * (-50.0/100))+22;
                    yOffset = int(guiSize.y * (50.0/100))-14;
                    layer = 0.9999;
                    break;
                case 102:
                    xOffset = int(guiSize.x * (-50.0/100))+32;
                    yOffset = int(guiSize.y * (50.0/100))-12;
                    layer = 1.0;
                    break;
                case 103:
                    xOffset = int(guiSize.x * (-50.0/100))+91;
                    yOffset = int(guiSize.y * (0.0/100))+29;
                    layer = 0.9999;
                    break;
                case 104:
                    xOffset = int(guiSize.x * (-50.0/100))+90;
                    yOffset = int(guiSize.y * (0.0/100))+28;
                    layer = 1.0;
                    break;
                case 105:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9999;
                    break;
                case 106:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+44;
                    layer = 1.0;
                    break;
                case 107:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 1.0;
                    break;
                case 108:
                    xOffset = int(guiSize.x * (-50.0/100))-12;
                    yOffset = int(guiSize.y * (0.0/100))+40;
                    layer = 0.9995;
                    break;
                case 109:
                    xOffset = int(guiSize.x * (-50.0/100))-13;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9996;
                    break;
                case 110:
                    xOffset = int(guiSize.x * (-50.0/100))-13;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9997;
                    break;
                case 111:
                    xOffset = int(guiSize.x * (-50.0/100))-80;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9998;
                    break;
                case 112:
                    xOffset = int(guiSize.x * (-50.0/100))-80;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9999;
                    break;
                case 113:
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+40;
                    layer = 1.0;
                    break;
                case 114:
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+43;
                    layer = 1.0;
                    break;
                case 115:
                    xOffset = int(guiSize.x * (-50.0/100))-12;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9997;
                    break;
                case 116:
                    xOffset = int(guiSize.x * (-50.0/100))-13;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9998;
                    break;
                case 117:
                    xOffset = int(guiSize.x * (-50.0/100))-80;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9999;
                    break;
                case 118:
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 1.0;
                    break;
                case 119:
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+51;
                    layer = 1.0;
                    break;
                case 120:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 121:
                    xOffset = int(guiSize.x * (-50.0/100))+79;
                    yOffset = int(guiSize.y * (0.0/100))+40;
                    layer = 0.9986000000000002;
                    break;
                case 122:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9987000000000001;
                    break;
                case 123:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9988000000000001;
                    break;
                case 124:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9989000000000001;
                    break;
                case 125:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9990000000000001;
                    break;
                case 126:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9991000000000001;
                    break;
                case 127:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9992000000000001;
                    break;
                case 128:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9993000000000001;
                    break;
                case 129:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9994000000000001;
                    break;
                case 130:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9995;
                    break;
                case 131:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9996;
                    break;
            }
        }
        else if (id >= 132.0 && id <= 163.0) {
            switch (int(id)) {
                case 132:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9997;
                    break;
                case 133:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+41;
                    layer = 0.9998;
                    break;
                case 134:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+40;
                    layer = 0.9999;
                    break;
                case 135:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+43;
                    layer = 0.9999;
                    break;
                case 136:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+40;
                    layer = 1.0;
                    break;
                case 137:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+43;
                    layer = 1.0;
                    break;
                case 138:
                    xOffset = int(guiSize.x * (-50.0/100))+79;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9997;
                    break;
                case 139:
                    xOffset = int(guiSize.x * (-50.0/100))+78;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9998;
                    break;
                case 140:
                    xOffset = int(guiSize.x * (-50.0/100))+89;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9999;
                    break;
                case 141:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 1.0;
                    break;
                case 142:
                    xOffset = int(guiSize.x * (-50.0/100))+46;
                    yOffset = int(guiSize.y * (0.0/100))+51;
                    layer = 1.0;
                    break;
                case 143:
                    xOffset = int(guiSize.x * (-50.0/100))+91;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 144:
                    xOffset = int(guiSize.x * (-50.0/100))+70;
                    yOffset = int(guiSize.y * (100.0/100))-3;
                    layer = 0.9998;
                    break;
                case 145:
                    xOffset = int(guiSize.x * (-50.0/100))+67;
                    yOffset = int(guiSize.y * (100.0/100))-5;
                    layer = 0.9999;
                    break;
                case 146:
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (100.0/100))-7;
                    layer = 1.0;
                    break;
                case 147:
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 1.0;
                    break;
                case 148:
                    xOffset = int(guiSize.x * (-0.0/100))-58;
                    yOffset = int(guiSize.y * (100.0/100))-32;
                    layer = 0.9994000000000001;
                    break;
                case 149:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-33;
                    layer = 0.9995;
                    break;
                case 150:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-33;
                    layer = 0.9996;
                    break;
                case 151:
                    xOffset = int(guiSize.x * (-0.0/100))-48;
                    yOffset = int(guiSize.y * (100.0/100))-32;
                    layer = 0.9997;
                    break;
                case 152:
                    xOffset = int(guiSize.x * (-0.0/100))-48;
                    yOffset = int(guiSize.y * (100.0/100))-32;
                    layer = 0.9998;
                    break;
                case 153:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-34;
                    layer = 0.9999;
                    break;
                case 154:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-31;
                    layer = 0.9999;
                    break;
                case 155:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-34;
                    layer = 1.0;
                    break;
                case 156:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-31;
                    layer = 1.0;
                    break;
                case 157:
                    xOffset = int(guiSize.x * (-0.0/100))-58;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9997;
                    break;
                case 158:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-21;
                    layer = 0.9998;
                    break;
                case 159:
                    xOffset = int(guiSize.x * (-0.0/100))-48;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9999;
                    break;
                case 160:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 1.0;
                    break;
                case 161:
                    xOffset = int(guiSize.x * (-0.0/100))-111;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 1.0;
                    break;
                case 162:
                    xOffset = int(guiSize.x * (-0.0/100))-44;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9992000000000001;
                    break;
                case 163:
                    xOffset = int(guiSize.x * (-0.0/100))-4;
                    yOffset = int(guiSize.y * (100.0/100))-5;
                    layer = 0.9993000000000001;
                    break;
            }
        }
        else if (id >= 164.0 && id <= 195.0) {
            switch (int(id)) {
                case 164:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9994000000000001;
                    break;
                case 165:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))-9;
                    layer = 0.9994000000000001;
                    break;
                case 166:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))-6;
                    layer = 0.9994000000000001;
                    break;
                case 167:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))-3;
                    layer = 0.9994000000000001;
                    break;
                case 168:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100));
                    layer = 0.9994000000000001;
                    break;
                case 169:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))+3;
                    layer = 0.9994000000000001;
                    break;
                case 170:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))+6;
                    layer = 0.9994000000000001;
                    break;
                case 171:
                    xOffset = int(guiSize.x * (-0.0/100))-11;
                    yOffset = int(guiSize.y * (100.0/100))+9;
                    layer = 0.9994000000000001;
                    break;
                case 172:
                    xOffset = int(guiSize.x * (-0.0/100))-113;
                    yOffset = int(guiSize.y * (100.0/100))-8;
                    layer = 0.9995;
                    break;
                case 173:
                    xOffset = int(guiSize.x * (-0.0/100))-48;
                    yOffset = int(guiSize.y * (100.0/100))-8;
                    layer = 0.9996;
                    break;
                case 174:
                    xOffset = int(guiSize.x * (-0.0/100))-124;
                    yOffset = int(guiSize.y * (100.0/100))-9;
                    layer = 0.9997;
                    break;
                case 175:
                    xOffset = int(guiSize.x * (-0.0/100))-124;
                    yOffset = int(guiSize.y * (100.0/100))-6;
                    layer = 0.9997;
                    break;
                case 176:
                    xOffset = int(guiSize.x * (-0.0/100))-124;
                    yOffset = int(guiSize.y * (100.0/100))-9;
                    layer = 0.9998;
                    break;
                case 177:
                    xOffset = int(guiSize.x * (-0.0/100))-124;
                    yOffset = int(guiSize.y * (100.0/100))-6;
                    layer = 0.9998;
                    break;
                case 178:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-9;
                    layer = 0.9999;
                    break;
                case 179:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-6;
                    layer = 0.9999;
                    break;
                case 180:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-9;
                    layer = 1.0;
                    break;
                case 181:
                    xOffset = int(guiSize.x * (-0.0/100))-59;
                    yOffset = int(guiSize.y * (100.0/100))-6;
                    layer = 1.0;
                    break;
                case 182:
                    xOffset = int(guiSize.x * (-50.0/100))+76;
                    yOffset = int(guiSize.y * (0.0/100))+101;
                    layer = 0.9963000000000004;
                    break;
                case 183:
                    xOffset = int(guiSize.x * (-50.0/100))-52;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9964000000000004;
                    break;
                case 184:
                    xOffset = int(guiSize.x * (-50.0/100))-55;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9965000000000004;
                    break;
                case 185:
                    xOffset = int(guiSize.x * (-50.0/100))-55;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9966000000000004;
                    break;
                case 186:
                    xOffset = int(guiSize.x * (-50.0/100))-55;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9967000000000004;
                    break;
                case 187:
                    xOffset = int(guiSize.x * (-50.0/100))-63;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9968000000000004;
                    break;
                case 188:
                    xOffset = int(guiSize.x * (-50.0/100))-63;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9968000000000004;
                    break;
                case 189:
                    xOffset = int(guiSize.x * (-50.0/100))-68;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9969000000000003;
                    break;
                case 190:
                    xOffset = int(guiSize.x * (-50.0/100))-27;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9970000000000003;
                    break;
                case 191:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9971000000000003;
                    break;
                case 192:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9972000000000003;
                    break;
                case 193:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9973000000000003;
                    break;
                case 194:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9974000000000003;
                    break;
                case 195:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9974000000000003;
                    break;
            }
        }
        else if (id >= 196.0 && id <= 227.0) {
            switch (int(id)) {
                case 196:
                    xOffset = int(guiSize.x * (-50.0/100))-43;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9975000000000003;
                    break;
                case 197:
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9976000000000003;
                    break;
                case 198:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9977000000000003;
                    break;
                case 199:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9978000000000002;
                    break;
                case 200:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9979000000000002;
                    break;
                case 201:
                    xOffset = int(guiSize.x * (-50.0/100))-13;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9980000000000002;
                    break;
                case 202:
                    xOffset = int(guiSize.x * (-50.0/100))-13;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9980000000000002;
                    break;
                case 203:
                    xOffset = int(guiSize.x * (-50.0/100))-18;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9981000000000002;
                    break;
                case 204:
                    xOffset = int(guiSize.x * (-50.0/100))+23;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9982000000000002;
                    break;
                case 205:
                    xOffset = int(guiSize.x * (-50.0/100))+20;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9983000000000002;
                    break;
                case 206:
                    xOffset = int(guiSize.x * (-50.0/100))+20;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9984000000000002;
                    break;
                case 207:
                    xOffset = int(guiSize.x * (-50.0/100))+20;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9985000000000002;
                    break;
                case 208:
                    xOffset = int(guiSize.x * (-50.0/100))+12;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9986000000000002;
                    break;
                case 209:
                    xOffset = int(guiSize.x * (-50.0/100))+12;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9986000000000002;
                    break;
                case 210:
                    xOffset = int(guiSize.x * (-50.0/100))+7;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9987000000000001;
                    break;
                case 211:
                    xOffset = int(guiSize.x * (-50.0/100))+48;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9988000000000001;
                    break;
                case 212:
                    xOffset = int(guiSize.x * (-50.0/100))+45;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9989000000000001;
                    break;
                case 213:
                    xOffset = int(guiSize.x * (-50.0/100))+45;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9990000000000001;
                    break;
                case 214:
                    xOffset = int(guiSize.x * (-50.0/100))+45;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9991000000000001;
                    break;
                case 215:
                    xOffset = int(guiSize.x * (-50.0/100))+37;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9992000000000001;
                    break;
                case 216:
                    xOffset = int(guiSize.x * (-50.0/100))+37;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9992000000000001;
                    break;
                case 217:
                    xOffset = int(guiSize.x * (-50.0/100))+32;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9993000000000001;
                    break;
                case 218:
                    xOffset = int(guiSize.x * (-50.0/100))+73;
                    yOffset = int(guiSize.y * (0.0/100))+98;
                    layer = 0.9994000000000001;
                    break;
                case 219:
                    xOffset = int(guiSize.x * (-50.0/100))+70;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9995;
                    break;
                case 220:
                    xOffset = int(guiSize.x * (-50.0/100))+70;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9996;
                    break;
                case 221:
                    xOffset = int(guiSize.x * (-50.0/100))+70;
                    yOffset = int(guiSize.y * (0.0/100))+95;
                    layer = 0.9997;
                    break;
                case 222:
                    xOffset = int(guiSize.x * (-50.0/100))+62;
                    yOffset = int(guiSize.y * (0.0/100))+91;
                    layer = 0.9998;
                    break;
                case 223:
                    xOffset = int(guiSize.x * (-50.0/100))+62;
                    yOffset = int(guiSize.y * (0.0/100))+94;
                    layer = 0.9998;
                    break;
                case 224:
                    xOffset = int(guiSize.x * (-50.0/100))+57;
                    yOffset = int(guiSize.y * (0.0/100))+83;
                    layer = 0.9999;
                    break;
                case 225:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+112;
                    layer = 1.0;
                    break;
                case 226:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+115;
                    layer = 1.0;
                    break;
                case 227:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+22;
                    layer = 1.0;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 228.0 && id <= 259.0) {
            switch (int(id)) {
                case 228:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+25;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 229:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+8;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 230:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 231:
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+5;
                    layer = 1.0;
                    break;
                case 232:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9998;
                    break;
                case 233:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9999;
                    break;
                case 234:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+67;
                    layer = 1.0;
                    break;
                case 235:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9998;
                    break;
                case 236:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9999;
                    break;
                case 237:
                    xOffset = int(guiSize.x * (-50.0/100))+15;
                    yOffset = int(guiSize.y * (0.0/100))+67;
                    layer = 1.0;
                    break;
                case 238:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9998;
                    break;
                case 239:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9999;
                    break;
                case 240:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+57;
                    layer = 1.0;
                    break;
                case 241:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9998;
                    break;
                case 242:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9999;
                    break;
                case 243:
                    xOffset = int(guiSize.x * (-50.0/100))+15;
                    yOffset = int(guiSize.y * (0.0/100))+57;
                    layer = 1.0;
                    break;
                case 244:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9994000000000001;
                    break;
                case 245:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9995;
                    break;
                case 246:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9996;
                    break;
                case 247:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9997;
                    break;
                case 248:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 249:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+14;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 250:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 251:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+14;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 252:
                    xOffset = int(guiSize.x * (-100.0/100))+12;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 1.0;
                    break;
                case 253:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+37;
                    layer = 0.9996;
                    break;
                case 254:
                    xOffset = int(guiSize.x * (-50.0/100))+1;
                    yOffset = int(guiSize.y * (0.0/100))+27;
                    layer = 0.9997;
                    break;
                case 255:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+26;
                    layer = 0.9998;
                    break;
                case 256:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-149;
                    yOffset = int(guiSize.y * (0.0/100))+27;
                    layer = 0.9999;
                    break;
                case 257:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-149;
                    yOffset = int(guiSize.y * (0.0/100))+30;
                    layer = 0.9999;
                    break;
                case 258:
                    xOffset = int(guiSize.x * (-50.0/100))-88;
                    yOffset = int(guiSize.y * (0.0/100))+28;
                    layer = 1.0;
                    break;
                case 259:
                    xOffset = int(guiSize.x * (-50.0/100))-88;
                    yOffset = int(guiSize.y * (0.0/100))+31;
                    layer = 1.0;
                    break;
            }
        }
        else if (id >= 260.0 && id <= 291.0) {
            switch (int(id)) {
                case 260:
                    xOffset = int(guiSize.x * (-50.0/100))+1;
                    yOffset = int(guiSize.y * (50.0/100))-12;
                    layer = 0.9998;
                    break;
                case 261:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-13;
                    layer = 0.9999;
                    break;
                case 262:
                    xOffset = int(guiSize.x * (-50.0/100))+2;
                    yOffset = int(guiSize.y * (50.0/100))-10;
                    layer = 1.0;
                    break;
                case 263:
                    xOffset = int(guiSize.x * (-50.0/100))-1;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9997;
                    break;
                case 264:
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9998;
                    break;
                case 265:
                    xOffset = int(guiSize.x * (-50.0/100))-90;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9999;
                    break;
                case 266:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 1.0;
                    break;
                case 267:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 268:
                    xOffset = int(guiSize.x * (-50.0/100))+44;
                    yOffset = int(guiSize.y * (0.0/100))+38;
                    layer = 0.9995;
                    break;
                case 269:
                    xOffset = int(guiSize.x * (-50.0/100))+43;
                    yOffset = int(guiSize.y * (0.0/100))+37;
                    layer = 0.9996;
                    break;
                case 270:
                    xOffset = int(guiSize.x * (-50.0/100))+54;
                    yOffset = int(guiSize.y * (0.0/100))+38;
                    layer = 0.9997;
                    break;
                case 271:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 0.9998;
                    break;
                case 272:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9998;
                    break;
                case 273:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 0.9999;
                    break;
                case 274:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9999;
                    break;
                case 275:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 1.0;
                    break;
                case 276:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 1.0;
                    break;
                case 277:
                    xOffset = int(guiSize.x * (-50.0/100))+99;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9983000000000002;
                    break;
                case 278:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9984000000000002;
                    break;
                case 279:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9985000000000002;
                    break;
                case 280:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9986000000000002;
                    break;
                case 281:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9987000000000001;
                    break;
                case 282:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9988000000000001;
                    break;
                case 283:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9989000000000001;
                    break;
                case 284:
                    xOffset = int(guiSize.x * (-50.0/100))+99;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9990000000000001;
                    break;
                case 285:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9991000000000001;
                    break;
                case 286:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9992000000000001;
                    break;
                case 287:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9993000000000001;
                    break;
                case 288:
                    xOffset = int(guiSize.x * (-50.0/100))+108;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9994000000000001;
                    break;
                case 289:
                    xOffset = int(guiSize.x * (-50.0/100))+108;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9995;
                    break;
                case 290:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9996;
                    break;
                case 291:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+49;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9997;
                    break;
            }
        }
        else if (id >= 292.0 && id <= 323.0) {
            switch (int(id)) {
                case 292:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+49;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9997;
                    break;
                case 293:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+53;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9998;
                    break;
                case 294:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+53;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9998;
                    break;
                case 295:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9999;
                    break;
                case 296:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9999;
                    break;
                case 297:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 1.0;
                    break;
                case 298:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 299:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9989000000000001;
                    break;
                case 300:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-97;
                    layer = 0.9990000000000001;
                    break;
                case 301:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-98;
                    layer = 0.9991000000000001;
                    break;
                case 302:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9992000000000001;
                    break;
                case 303:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-91;
                    layer = 0.9993000000000001;
                    break;
                case 304:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-91;
                    layer = 0.9994000000000001;
                    break;
                case 305:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 306:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 307:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 308:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 309:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 310:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 311:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 312:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 313:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9999;
                    break;
                case 314:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 1.0;
                    break;
                case 315:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-54;
                    layer = 0.9989000000000001;
                    break;
                case 316:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-71;
                    layer = 0.9990000000000001;
                    break;
                case 317:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-72;
                    layer = 0.9991000000000001;
                    break;
                case 318:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9992000000000001;
                    break;
                case 319:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-65;
                    layer = 0.9993000000000001;
                    break;
                case 320:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-65;
                    layer = 0.9994000000000001;
                    break;
                case 321:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 322:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 323:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9996;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 324.0 && id <= 355.0) {
            switch (int(id)) {
                case 324:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 325:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 326:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 327:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 328:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-54;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 329:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 0.9999;
                    break;
                case 330:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 1.0;
                    break;
                case 331:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-28;
                    layer = 0.9989000000000001;
                    break;
                case 332:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-45;
                    layer = 0.9990000000000001;
                    break;
                case 333:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-46;
                    layer = 0.9991000000000001;
                    break;
                case 334:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9992000000000001;
                    break;
                case 335:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9993000000000001;
                    break;
                case 336:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9994000000000001;
                    break;
                case 337:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 338:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 339:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 340:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 341:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 342:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 343:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 344:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-28;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 345:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 0.9999;
                    break;
                case 346:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 1.0;
                    break;
                case 347:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-2;
                    layer = 0.9988000000000001;
                    break;
                case 348:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9989000000000001;
                    break;
                case 349:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9990000000000001;
                    break;
                case 350:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9991000000000001;
                    break;
                case 351:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-13;
                    layer = 0.9992000000000001;
                    break;
                case 352:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-13;
                    layer = 0.9993000000000001;
                    break;
                case 353:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9994000000000001;
                    outlined = true;
                    break;
                case 354:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9994000000000001;
                    outlined = true;
                    break;
                case 355:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9995;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 356.0 && id <= 387.0) {
            switch (int(id)) {
                case 356:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 357:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 358:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 359:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 360:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-2;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 361:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9998;
                    break;
                case 362:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9999;
                    break;
                case 363:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-116;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 1.0;
                    break;
                case 364:
                    xOffset = int(guiSize.x * (-50.0/100))-78;
                    yOffset = int(guiSize.y * (0.0/100))+102;
                    layer = 0.9964000000000004;
                    break;
                case 365:
                    xOffset = int(guiSize.x * (-50.0/100))-78;
                    yOffset = int(guiSize.y * (0.0/100))+105;
                    layer = 0.9964000000000004;
                    break;
                case 366:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9965000000000004;
                    break;
                case 367:
                    xOffset = int(guiSize.x * (-50.0/100))-136;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9966000000000004;
                    break;
                case 368:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9967000000000004;
                    break;
                case 369:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9968000000000004;
                    break;
                case 370:
                    xOffset = int(guiSize.x * (-50.0/100))-146;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9969000000000003;
                    break;
                case 371:
                    xOffset = int(guiSize.x * (-50.0/100))-146;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9969000000000003;
                    break;
                case 372:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9970000000000003;
                    break;
                case 373:
                    xOffset = int(guiSize.x * (-50.0/100))-109;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9971000000000003;
                    break;
                case 374:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9972000000000003;
                    break;
                case 375:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9973000000000003;
                    break;
                case 376:
                    xOffset = int(guiSize.x * (-50.0/100))-119;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9974000000000003;
                    break;
                case 377:
                    xOffset = int(guiSize.x * (-50.0/100))-119;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9974000000000003;
                    break;
                case 378:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9975000000000003;
                    break;
                case 379:
                    xOffset = int(guiSize.x * (-50.0/100))-82;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9976000000000003;
                    break;
                case 380:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9977000000000003;
                    break;
                case 381:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9978000000000002;
                    break;
                case 382:
                    xOffset = int(guiSize.x * (-50.0/100))-92;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9979000000000002;
                    break;
                case 383:
                    xOffset = int(guiSize.x * (-50.0/100))-92;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9979000000000002;
                    break;
                case 384:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9980000000000002;
                    break;
                case 385:
                    xOffset = int(guiSize.x * (-50.0/100))-55;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9981000000000002;
                    break;
                case 386:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9982000000000002;
                    break;
                case 387:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9983000000000002;
                    break;
            }
        }
        else if (id >= 388.0 && id <= 419.0) {
            switch (int(id)) {
                case 388:
                    xOffset = int(guiSize.x * (-50.0/100))-65;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9984000000000002;
                    break;
                case 389:
                    xOffset = int(guiSize.x * (-50.0/100))-65;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9984000000000002;
                    break;
                case 390:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9985000000000002;
                    break;
                case 391:
                    xOffset = int(guiSize.x * (-50.0/100))-28;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9986000000000002;
                    break;
                case 392:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9987000000000001;
                    break;
                case 393:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9988000000000001;
                    break;
                case 394:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9989000000000001;
                    break;
                case 395:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9989000000000001;
                    break;
                case 396:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9990000000000001;
                    break;
                case 397:
                    xOffset = int(guiSize.x * (-50.0/100))-1;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9991000000000001;
                    break;
                case 398:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9992000000000001;
                    break;
                case 399:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9993000000000001;
                    break;
                case 400:
                    xOffset = int(guiSize.x * (-50.0/100))-11;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9994000000000001;
                    break;
                case 401:
                    xOffset = int(guiSize.x * (-50.0/100))-11;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9994000000000001;
                    break;
                case 402:
                    xOffset = int(guiSize.x * (-50.0/100))-144;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9995;
                    break;
                case 403:
                    xOffset = int(guiSize.x * (-50.0/100))-117;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9996;
                    break;
                case 404:
                    xOffset = int(guiSize.x * (-50.0/100))-90;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9997;
                    break;
                case 405:
                    xOffset = int(guiSize.x * (-50.0/100))-63;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9998;
                    break;
                case 406:
                    xOffset = int(guiSize.x * (-50.0/100))-36;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9999;
                    break;
                case 407:
                    xOffset = int(guiSize.x * (-50.0/100))-9;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 1.0;
                    break;
                case 408:
                    xOffset = int(guiSize.x * (-0.0/100))-25;
                    yOffset = int(guiSize.y * (100.0/100))-25;
                    layer = 0.9996;
                    break;
                case 409:
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-37;
                    layer = 0.9997;
                    break;
                case 410:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-45;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 411:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 412:
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-31;
                    layer = 0.9999;
                    break;
                case 413:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-21;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 414:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-18;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 415:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-10;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 416:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-7;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 417:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-20;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 418:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-17;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 419:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-30;
                    layer = 1.0;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 420.0 && id <= 450.0) {
            switch (int(id)) {
                case 420:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-27;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 421:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9997;
                    break;
                case 422:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 423:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 424:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 425:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 426:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 1.0;
                    break;
                case 427:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-40;
                    layer = 0.9997;
                    break;
                case 428:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 429:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 430:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 431:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 432:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 1.0;
                    break;
                case 433:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-60;
                    layer = 0.9997;
                    break;
                case 434:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 435:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-59;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 436:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 437:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-59;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 438:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 1.0;
                    break;
                case 439:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9997;
                    break;
                case 440:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 441:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-79;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 442:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 443:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-79;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 444:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 1.0;
                    break;
                case 445:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-100;
                    layer = 0.9997;
                    break;
                case 446:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 447:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-99;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 448:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 449:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-99;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 450:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 1.0;
                    break;
            }
        }


        // -2800.0 is required for forge comp
        if ((Position.z != 1000.0 && Position.z != -2800.0) || outlined) {
            pos.y -= (id*1000) + 500 + MH_OFFSET;
            pos.x -= (guiSize.x * 0.5);

            pos.x *= scale.x;
            pos.y *= scale.y;

            pos.y += guiSize.y;
            // force align guiScale 3
            if (guiScale == 3) {
                pos.x += 1.45;
            }

            pos -= vec3(xOffset, yOffset, 0.0);
            pos.z += layer;
        }
    } else if (XP_HIDE) {
        int offset = int(round(guiSize.y - Position.y));

        if ((within(Color.rgb, XP_COLOR, 0.002) && is_at(offset, 26, 27)) || (within(Color.rgb, XP_COLOR_SHADOW, 0.002) && is_at(offset, 25, 26, 27, 28))) {
            pos += XP_OFFSET;
        }
    }

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
