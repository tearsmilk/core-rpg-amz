#ifndef MYTHICHUD_UTILS_GLSL
#define MYTHICHUD_UTILS_GLSL

#define MH_VERSION 5
#define MH_OFFSET 67
#define XP_HIDE true
#define XP_OFFSET vec3(-10600.0, -10600.0, -10600.0)
#define XP_COLOR vec3(0.501, 1.0, 0.125)
#define XP_COLOR_SHADOW vec3(0.0, 0.0, 0.0)

#include <minecraft:globals.glsl>

// Function to convert a vertical ascent into a ID.
float get_id(float offset) {
    if (offset <= 0.0)
    return 0.0;
    return trunc(offset / 1000.0);
}

bool is_at(int offset, int pos) { return offset == pos || offset == pos + 8; }
bool is_at(int offset, int pos0, int pos1) { return is_at(offset, pos0) || is_at(offset, pos1); }
bool is_at(int offset, int pos0, int pos1, int pos2, int pos3) { return is_at(offset, pos0, pos1) || is_at(offset, pos2, pos3); }
bool within(vec3 a, vec3 b, float threshold) { return abs(length(a - b)) < threshold; }

void applyCustomHud() {
    vec3 pos = Position;
    vec2 guiSize = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    int guiScale = int(round(guiSize.x / (1 / ScreenSize.x)));

    float id = get_id((round(MH_OFFSET - pos.y)) * -1);

    // Detect if GUI text.
    if (id > 99 && Color.a != 0.0) {
        float yOffset = 0.0;
        float xOffset = 0.0;
        float layer = 0.0;
        vec2 scale = vec2(1, 1);
        bool outlined = false;

        if (id >= 100.0 && id <= 131.0) {
            switch (int(id)) {
                case 100:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+22;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 101:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+25;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 102:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+8;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 103:
                    xOffset = int(guiSize.x * (-0.0/100))-40;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 104:
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+5;
                    layer = 1.0;
                    break;
                case 105:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9998;
                    break;
                case 106:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9999;
                    break;
                case 107:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+67;
                    layer = 1.0;
                    break;
                case 108:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9998;
                    break;
                case 109:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+65;
                    layer = 0.9999;
                    break;
                case 110:
                    xOffset = int(guiSize.x * (-50.0/100))+15;
                    yOffset = int(guiSize.y * (0.0/100))+67;
                    layer = 1.0;
                    break;
                case 111:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9998;
                    break;
                case 112:
                    xOffset = int(guiSize.x * (-50.0/100))-10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9999;
                    break;
                case 113:
                    xOffset = int(guiSize.x * (-50.0/100))-5;
                    yOffset = int(guiSize.y * (0.0/100))+57;
                    layer = 1.0;
                    break;
                case 114:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9998;
                    break;
                case 115:
                    xOffset = int(guiSize.x * (-50.0/100))+10;
                    yOffset = int(guiSize.y * (0.0/100))+55;
                    layer = 0.9999;
                    break;
                case 116:
                    xOffset = int(guiSize.x * (-50.0/100))+15;
                    yOffset = int(guiSize.y * (0.0/100))+57;
                    layer = 1.0;
                    break;
                case 117:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9994000000000001;
                    break;
                case 118:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9995;
                    break;
                case 119:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9996;
                    break;
                case 120:
                    xOffset = int(guiSize.x * (-100.0/100))+2;
                    yOffset = int(guiSize.y * (0.0/100))+13;
                    layer = 0.9997;
                    break;
                case 121:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 122:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+14;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 123:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 124:
                    xOffset = int(guiSize.x * (-100.0/100))+13;
                    yOffset = int(guiSize.y * (0.0/100))+14;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 125:
                    xOffset = int(guiSize.x * (-100.0/100))+12;
                    yOffset = int(guiSize.y * (0.0/100))+11;
                    layer = 1.0;
                    break;
                case 126:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+37;
                    layer = 0.9996;
                    break;
                case 127:
                    xOffset = int(guiSize.x * (-50.0/100))+1;
                    yOffset = int(guiSize.y * (0.0/100))+27;
                    layer = 0.9997;
                    break;
                case 128:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+26;
                    layer = 0.9998;
                    break;
                case 129:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-149;
                    yOffset = int(guiSize.y * (0.0/100))+27;
                    layer = 0.9999;
                    break;
                case 130:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-149;
                    yOffset = int(guiSize.y * (0.0/100))+30;
                    layer = 0.9999;
                    break;
                case 131:
                    xOffset = int(guiSize.x * (-50.0/100))-88;
                    yOffset = int(guiSize.y * (0.0/100))+28;
                    layer = 1.0;
                    break;
            }
        }
        else if (id >= 132.0 && id <= 163.0) {
            switch (int(id)) {
                case 132:
                    xOffset = int(guiSize.x * (-50.0/100))-88;
                    yOffset = int(guiSize.y * (0.0/100))+31;
                    layer = 1.0;
                    break;
                case 133:
                    xOffset = int(guiSize.x * (-50.0/100))+1;
                    yOffset = int(guiSize.y * (50.0/100))-12;
                    layer = 0.9998;
                    break;
                case 134:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-13;
                    layer = 0.9999;
                    break;
                case 135:
                    xOffset = int(guiSize.x * (-50.0/100))+2;
                    yOffset = int(guiSize.y * (50.0/100))-10;
                    layer = 1.0;
                    break;
                case 136:
                    xOffset = int(guiSize.x * (-50.0/100))-1;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9997;
                    break;
                case 137:
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9998;
                    break;
                case 138:
                    xOffset = int(guiSize.x * (-50.0/100))-90;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9999;
                    break;
                case 139:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 1.0;
                    break;
                case 140:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-45;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 141:
                    xOffset = int(guiSize.x * (-50.0/100))+44;
                    yOffset = int(guiSize.y * (0.0/100))+38;
                    layer = 0.9995;
                    break;
                case 142:
                    xOffset = int(guiSize.x * (-50.0/100))+43;
                    yOffset = int(guiSize.y * (0.0/100))+37;
                    layer = 0.9996;
                    break;
                case 143:
                    xOffset = int(guiSize.x * (-50.0/100))+54;
                    yOffset = int(guiSize.y * (0.0/100))+38;
                    layer = 0.9997;
                    break;
                case 144:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 0.9998;
                    break;
                case 145:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-6;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9998;
                    break;
                case 146:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 0.9999;
                    break;
                case 147:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))-2;
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 0.9999;
                    break;
                case 148:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+36;
                    layer = 1.0;
                    break;
                case 149:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (0.0/100))+39;
                    layer = 1.0;
                    break;
                case 150:
                    xOffset = int(guiSize.x * (-50.0/100))+99;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9983000000000002;
                    break;
                case 151:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9984000000000002;
                    break;
                case 152:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9985000000000002;
                    break;
                case 153:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9986000000000002;
                    break;
                case 154:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9987000000000001;
                    break;
                case 155:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9988000000000001;
                    break;
                case 156:
                    xOffset = int(guiSize.x * (-50.0/100))+98;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9989000000000001;
                    break;
                case 157:
                    xOffset = int(guiSize.x * (-50.0/100))+99;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9990000000000001;
                    break;
                case 158:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9991000000000001;
                    break;
                case 159:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9992000000000001;
                    break;
                case 160:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9993000000000001;
                    break;
                case 161:
                    xOffset = int(guiSize.x * (-50.0/100))+108;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9994000000000001;
                    break;
                case 162:
                    xOffset = int(guiSize.x * (-50.0/100))+108;
                    yOffset = int(guiSize.y * (0.0/100))+48;
                    layer = 0.9995;
                    break;
                case 163:
                    xOffset = int(guiSize.x * (-50.0/100))+109;
                    yOffset = int(guiSize.y * (0.0/100))+49;
                    layer = 0.9996;
                    break;
            }
        }
        else if (id >= 164.0 && id <= 195.0) {
            switch (int(id)) {
                case 164:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+49;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9997;
                    break;
                case 165:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+49;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9997;
                    break;
                case 166:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+53;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9998;
                    break;
                case 167:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+53;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9998;
                    break;
                case 168:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 0.9999;
                    break;
                case 169:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 0.9999;
                    break;
                case 170:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+47;
                    layer = 1.0;
                    break;
                case 171:
                    scale.x = 0.7;
                    scale.y = 0.7;
                    xOffset = int(guiSize.x * (-50.0/100))+55;
                    yOffset = int(guiSize.y * (0.0/100))+50;
                    layer = 1.0;
                    break;
                case 172:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9989000000000001;
                    break;
                case 173:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-97;
                    layer = 0.9990000000000001;
                    break;
                case 174:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-98;
                    layer = 0.9991000000000001;
                    break;
                case 175:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9992000000000001;
                    break;
                case 176:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-91;
                    layer = 0.9993000000000001;
                    break;
                case 177:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-91;
                    layer = 0.9994000000000001;
                    break;
                case 178:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 179:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 180:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 181:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 182:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-90;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 183:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-88;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 184:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 185:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 186:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9999;
                    break;
                case 187:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 1.0;
                    break;
                case 188:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-54;
                    layer = 0.9989000000000001;
                    break;
                case 189:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-71;
                    layer = 0.9990000000000001;
                    break;
                case 190:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-72;
                    layer = 0.9991000000000001;
                    break;
                case 191:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9992000000000001;
                    break;
                case 192:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-65;
                    layer = 0.9993000000000001;
                    break;
                case 193:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-65;
                    layer = 0.9994000000000001;
                    break;
                case 194:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 195:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9995;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 196.0 && id <= 227.0) {
            switch (int(id)) {
                case 196:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 197:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 198:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-64;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 199:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 200:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 201:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-54;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 202:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 0.9999;
                    break;
                case 203:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-56;
                    layer = 1.0;
                    break;
                case 204:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-28;
                    layer = 0.9989000000000001;
                    break;
                case 205:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-45;
                    layer = 0.9990000000000001;
                    break;
                case 206:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-46;
                    layer = 0.9991000000000001;
                    break;
                case 207:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9992000000000001;
                    break;
                case 208:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9993000000000001;
                    break;
                case 209:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9994000000000001;
                    break;
                case 210:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 211:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 212:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 213:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 214:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-38;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 215:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-36;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 216:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 217:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-28;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 218:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 0.9999;
                    break;
                case 219:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-30;
                    layer = 1.0;
                    break;
                case 220:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-2;
                    yOffset = int(guiSize.y * (100.0/100))-2;
                    layer = 0.9988000000000001;
                    break;
                case 221:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9989000000000001;
                    break;
                case 222:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9990000000000001;
                    break;
                case 223:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9991000000000001;
                    break;
                case 224:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-13;
                    layer = 0.9992000000000001;
                    break;
                case 225:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-13;
                    layer = 0.9993000000000001;
                    break;
                case 226:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9994000000000001;
                    outlined = true;
                    break;
                case 227:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-78;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9994000000000001;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 228.0 && id <= 259.0) {
            switch (int(id)) {
                case 228:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 229:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-75;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9995;
                    outlined = true;
                    break;
                case 230:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-12;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 231:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-72;
                    yOffset = int(guiSize.y * (100.0/100))-10;
                    layer = 0.9996;
                    outlined = true;
                    break;
                case 232:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 233:
                    scale.x = 0.75;
                    scale.y = 0.75;
                    xOffset = int(guiSize.x * (-0.0/100))-26;
                    yOffset = int(guiSize.y * (100.0/100))-2;
                    layer = 0.9997;
                    outlined = true;
                    break;
                case 234:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9998;
                    break;
                case 235:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-5;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 0.9999;
                    break;
                case 236:
                    scale.x = 1.25;
                    scale.y = 1.25;
                    xOffset = int(guiSize.x * (-0.0/100))-116;
                    yOffset = int(guiSize.y * (100.0/100))-4;
                    layer = 1.0;
                    break;
                case 237:
                    xOffset = int(guiSize.x * (-50.0/100))-78;
                    yOffset = int(guiSize.y * (0.0/100))+102;
                    layer = 0.9964000000000004;
                    break;
                case 238:
                    xOffset = int(guiSize.x * (-50.0/100))-78;
                    yOffset = int(guiSize.y * (0.0/100))+105;
                    layer = 0.9964000000000004;
                    break;
                case 239:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9965000000000004;
                    break;
                case 240:
                    xOffset = int(guiSize.x * (-50.0/100))-136;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9966000000000004;
                    break;
                case 241:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9967000000000004;
                    break;
                case 242:
                    xOffset = int(guiSize.x * (-50.0/100))-138;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9968000000000004;
                    break;
                case 243:
                    xOffset = int(guiSize.x * (-50.0/100))-146;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9969000000000003;
                    break;
                case 244:
                    xOffset = int(guiSize.x * (-50.0/100))-146;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9969000000000003;
                    break;
                case 245:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9970000000000003;
                    break;
                case 246:
                    xOffset = int(guiSize.x * (-50.0/100))-109;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9971000000000003;
                    break;
                case 247:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9972000000000003;
                    break;
                case 248:
                    xOffset = int(guiSize.x * (-50.0/100))-111;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9973000000000003;
                    break;
                case 249:
                    xOffset = int(guiSize.x * (-50.0/100))-119;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9974000000000003;
                    break;
                case 250:
                    xOffset = int(guiSize.x * (-50.0/100))-119;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9974000000000003;
                    break;
                case 251:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9975000000000003;
                    break;
                case 252:
                    xOffset = int(guiSize.x * (-50.0/100))-82;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9976000000000003;
                    break;
                case 253:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9977000000000003;
                    break;
                case 254:
                    xOffset = int(guiSize.x * (-50.0/100))-84;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9978000000000002;
                    break;
                case 255:
                    xOffset = int(guiSize.x * (-50.0/100))-92;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9979000000000002;
                    break;
                case 256:
                    xOffset = int(guiSize.x * (-50.0/100))-92;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9979000000000002;
                    break;
                case 257:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9980000000000002;
                    break;
                case 258:
                    xOffset = int(guiSize.x * (-50.0/100))-55;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9981000000000002;
                    break;
                case 259:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9982000000000002;
                    break;
            }
        }
        else if (id >= 260.0 && id <= 291.0) {
            switch (int(id)) {
                case 260:
                    xOffset = int(guiSize.x * (-50.0/100))-57;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9983000000000002;
                    break;
                case 261:
                    xOffset = int(guiSize.x * (-50.0/100))-65;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9984000000000002;
                    break;
                case 262:
                    xOffset = int(guiSize.x * (-50.0/100))-65;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9984000000000002;
                    break;
                case 263:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9985000000000002;
                    break;
                case 264:
                    xOffset = int(guiSize.x * (-50.0/100))-28;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9986000000000002;
                    break;
                case 265:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9987000000000001;
                    break;
                case 266:
                    xOffset = int(guiSize.x * (-50.0/100))-30;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9988000000000001;
                    break;
                case 267:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9989000000000001;
                    break;
                case 268:
                    xOffset = int(guiSize.x * (-50.0/100))-38;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9989000000000001;
                    break;
                case 269:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9990000000000001;
                    break;
                case 270:
                    xOffset = int(guiSize.x * (-50.0/100))-1;
                    yOffset = int(guiSize.y * (0.0/100))+90;
                    layer = 0.9991000000000001;
                    break;
                case 271:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9992000000000001;
                    break;
                case 272:
                    xOffset = int(guiSize.x * (-50.0/100))-3;
                    yOffset = int(guiSize.y * (0.0/100))+88;
                    layer = 0.9993000000000001;
                    break;
                case 273:
                    xOffset = int(guiSize.x * (-50.0/100))-11;
                    yOffset = int(guiSize.y * (0.0/100))+84;
                    layer = 0.9994000000000001;
                    break;
                case 274:
                    xOffset = int(guiSize.x * (-50.0/100))-11;
                    yOffset = int(guiSize.y * (0.0/100))+87;
                    layer = 0.9994000000000001;
                    break;
                case 275:
                    xOffset = int(guiSize.x * (-50.0/100))-144;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9995;
                    break;
                case 276:
                    xOffset = int(guiSize.x * (-50.0/100))-117;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9996;
                    break;
                case 277:
                    xOffset = int(guiSize.x * (-50.0/100))-90;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9997;
                    break;
                case 278:
                    xOffset = int(guiSize.x * (-50.0/100))-63;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9998;
                    break;
                case 279:
                    xOffset = int(guiSize.x * (-50.0/100))-36;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 0.9999;
                    break;
                case 280:
                    xOffset = int(guiSize.x * (-50.0/100))-9;
                    yOffset = int(guiSize.y * (0.0/100))+74;
                    layer = 1.0;
                    break;
                case 281:
                    xOffset = int(guiSize.x * (-0.0/100))-25;
                    yOffset = int(guiSize.y * (100.0/100))-25;
                    layer = 0.9996;
                    break;
                case 282:
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-37;
                    layer = 0.9997;
                    break;
                case 283:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-45;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 284:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 285:
                    xOffset = int(guiSize.x * (-0.0/100))-27;
                    yOffset = int(guiSize.y * (100.0/100))-31;
                    layer = 0.9999;
                    break;
                case 286:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-21;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 287:
                    xOffset = int(guiSize.x * (-0.0/100))-28;
                    yOffset = int(guiSize.y * (100.0/100))-18;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 288:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-10;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 289:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-7;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 290:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-20;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 291:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-17;
                    layer = 1.0;
                    outlined = true;
                    break;
            }
        }
        else if (id >= 292.0 && id <= 323.0) {
            switch (int(id)) {
                case 292:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-30;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 293:
                    xOffset = int(guiSize.x * (-50.0/100));
                    yOffset = int(guiSize.y * (50.0/100))-27;
                    layer = 1.0;
                    outlined = true;
                    break;
                case 294:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-20;
                    layer = 0.9997;
                    break;
                case 295:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 296:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 297:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 298:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-19;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 299:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-22;
                    layer = 1.0;
                    break;
                case 300:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-40;
                    layer = 0.9997;
                    break;
                case 301:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 302:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 303:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 304:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-39;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 305:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-42;
                    layer = 1.0;
                    break;
                case 306:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-60;
                    layer = 0.9997;
                    break;
                case 307:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 308:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-59;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 309:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 310:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-59;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 311:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-62;
                    layer = 1.0;
                    break;
                case 312:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-80;
                    layer = 0.9997;
                    break;
                case 313:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 314:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-79;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 315:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 316:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-79;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 317:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-82;
                    layer = 1.0;
                    break;
                case 318:
                    xOffset = int(guiSize.x * (-100.0/100))+20;
                    yOffset = int(guiSize.y * (100.0/100))-100;
                    layer = 0.9997;
                    break;
                case 319:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 320:
                    xOffset = int(guiSize.x * (-100.0/100))-80;
                    yOffset = int(guiSize.y * (100.0/100))-99;
                    layer = 0.9998;
                    outlined = true;
                    break;
                case 321:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 322:
                    xOffset = int(guiSize.x * (-100.0/100))-60;
                    yOffset = int(guiSize.y * (100.0/100))-99;
                    layer = 0.9999;
                    outlined = true;
                    break;
                case 323:
                    xOffset = int(guiSize.x * (-100.0/100))-66;
                    yOffset = int(guiSize.y * (100.0/100))-102;
                    layer = 1.0;
                    break;
            }
        }


        // -2800.0 is required for forge comp
        if ((Position.z != 1000.0 && Position.z != -2800.0) || outlined) {
            pos.y -= (id*1000) + 500 + MH_OFFSET;
            pos.x -= (guiSize.x * 0.5);

            pos.x *= scale.x;
            pos.y *= scale.y;

            pos.y += guiSize.y;
            // force align guiScale 3
            if (guiScale == 3) {
                pos.x += 1.45;
            }

            pos -= vec3(xOffset, yOffset, 0.0);
            pos.z += layer;
        }
    } else if (XP_HIDE) {
        int offset = int(round(guiSize.y - Position.y));

        if ((within(Color.rgb, XP_COLOR, 0.002) && is_at(offset, 26, 27)) || (within(Color.rgb, XP_COLOR_SHADOW, 0.002) && is_at(offset, 25, 26, 27, 28))) {
            pos += XP_OFFSET;
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}

#endif
