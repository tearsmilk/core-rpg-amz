#version 330

vec4 cs_hook_text_fragment(vec4 color, vec4 vertexColor, vec2 uv) {
    return color;
}
